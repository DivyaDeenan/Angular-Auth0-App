# ngAuth0

Angular 9 application that implements Auth0 in a service and uses canActivate route guard and allows users to sign up, login, view profile and log out. Styled using bootswatch.

### Version
1.0.0

Uses Angular 2.0.1 Stable

### Usage


### Installation

```sh
$ npm install
```

### Compile


```sh
$ npm start
```
